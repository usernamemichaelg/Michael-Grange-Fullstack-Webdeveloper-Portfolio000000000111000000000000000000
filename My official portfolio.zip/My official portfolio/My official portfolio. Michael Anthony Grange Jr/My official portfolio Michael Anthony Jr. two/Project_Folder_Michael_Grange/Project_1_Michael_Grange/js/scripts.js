	$('#box1').hover(function() {

		$(this).text('Project one. Click the box.');

	});
		$('#box2').hover(function() {

		$(this).text('Project two. Click the box.');

	});
    	$('#box3').hover(function() {

		$(this).text('Project three. Click the box.');

	});
    	$('#box4').hover(function() {

		$(this).text('Project four. Click the box.');

	});

    
    $('#box1').click(function() {
		alert('Project one.')
});
    $('#box2').click(function() {
		alert('Project two.')
});
	$('#box3').click(function() {
		alert('Project three.')
});
	$('#box4').click(function() {
		alert('Project four.')
});

    