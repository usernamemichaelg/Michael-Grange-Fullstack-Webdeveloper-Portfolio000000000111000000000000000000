	$('#box').hover(function() {

		$(this).text('Click the box.');

	});
		$('#box').hover(function() {

		$(this).text('Project two. Click the box.');

	});
    	$('#box').hover(function() {

		$(this).text('Project three. Click the box.');

	});
    	$('#box').hover(function() {

		$(this).text('Click the box.');

	});

    
    $('#box1').click(function() {
		alert('Project one.')
});
    $('#box2').click(function() {
		alert('Project two.')
});
	$('#box3').click(function() {
		alert('Project three.')
});
	$('#box4').click(function() {
		alert('Project four.')
});


	    $('#Box1').click(function() {
		alert('Project one.')
});
    $('#Box2').click(function() {
		alert('Project two.')
});
	$('#Box3').click(function() {
		alert('Project three.')
});
	$('#Box4').click(function() {
		alert('Project four.')
});

    